<html>
<body>

		<?php
				$mavar ="wazaaa" ;
				echo $mavar ;
				
		?>			
<br>

       <?php
				$mavar ="kikou" ;
				echo $mavar ;
				
		?>
		

</body>
</html>