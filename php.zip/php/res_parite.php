<html>
<body>

<?php

		if ($_POST ['valeur']%2 == 0)

		{
			echo "La valeur" . $_POST ['valeur'] . " est paire";	
		}
		else
		{
		echo "La valeur" . $_POST ['valeur'] . " est impaire";	
		}
?>



</body>
</html>