<html>
 
 <body>
 
<form method = "POST"  action = "rez_calcul.php" >
 
  Valeur 1:
<input type = "text" name = "val1" size = "10">
  Valeur 2:
<input type = "text" name = "val2" size = "10">
 
  Op�ration: 
<input type = "radio" name = "operation" value = "add"> +
<input type = "radio" name = "operation" value = "sous"> -
<input type = "radio" name = "operation" value = "mul"> *
<input type = "radio" name = "operation" value = "div"> /

<input type = "submit" value = "Calculate">



</form>
 
 </body>
 
</html>
 
