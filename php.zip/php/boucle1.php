<html>
<body>

<div>
		<?php
			$cpt=0;
			while($cpt<=10)
			{
		?>	
		<p>
		<?php echo "ligne num�ro " . $cpt ;?>	
		</p>
		<?php	$cpt++;
				
			}
			
		?>	
	</div>	

</body>
</html>