<html>
<body>


		<?php
				echo $_GET ["recherche"] ;
		?>	
		

</body>
</html>