<html>
<body>


		<?php
				echo $_POST ["recherche"] ;
		?>	
		

</body>
</html>