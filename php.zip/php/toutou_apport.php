<html>
<body>

	
	<form method="GET" action="https://www.google.be/search" >
	<p>
			<label> c'est bien </label>
	</p>
	
	<p>
			<input type="text" name="q" value="" >
	</p>
	<p>
			<input type="submit"  value="trouve" >
	</p>
	</form>
		

</body>
</html>