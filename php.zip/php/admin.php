<html>
<body>
		<?php 
				if($_POST["ident"] == "akkad" && $_POST['mdp'] == "test")
				{
					echo "Bienvenu" . $_POST["ident"] ;
					
				}
			else
			{
				echo "Acc�s refus�! Le login" . $_POST["ident"] . "n'est pas valid" ;
			}
				
		?>
</body>
</html>