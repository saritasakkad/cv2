<html>
<body>
   <form method="GET" action="rez_cond.php" >          
						<p>
						<label>Veuiller entrer votre valeur</label>
						<input type="text"  name="valeur" />
                        </p>						
						<p>
						<input type="submit"  value="envoyer" />
						</p>		
</form>
</body>
</html>