<?php
		$a=$_POST['val'];
		echo "Table de multiplication de $a </br></br>";
		echo "<table border=1><tr>";
 
		for($i=0;$i<=10;$i++)
		{
			$r=$a*$i;
			echo "$i*$a=$r</tr> </br>";
		}
?>