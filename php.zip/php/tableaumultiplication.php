<HTML><BODY>
<TABLE BORDER>
<?php
// 1�re ligne

for ($c=1;$c<=10;$c++) {
  
}
echo "</TR>\n";
// toutes les lignes
for ($l=1;$l<=10;$l++) {
  // 1 ligne
  echo "<TR>";
  for ($c=1;$c<=10;$c++) {
    $r=$c*$l;
    echo "<TD ALIGN=right>$r</TD>";
  }  
  echo "</TR>\n";
}
?>
</TABLE>
</BODY></HTML>