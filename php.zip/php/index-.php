<html>
<body>
<div>

		<?php
				echo "Hello World !";
		?>	
		
		<br>
				
		<?php
				echo 'Salut Akkad va � l\'�cole ';
		?>

		
</div>
</body>
</html>