<html>
<body>

<?php

		if ($_POST ['operation'] == "add")

		{
			$somme = $_POST ['val1'] + $_POST ['val2'];
			echo "La somm est de " . $somme;
//echo $_POST ['val1'] . "+" . $_POST ['val2'] . "=" . $somme;			
		}
	
	
		if ($_POST ['operation'] == "sous")

		{
			$somme = $_POST ['val1'] - $_POST ['val2'];
			echo "La somm est de " . $somme;	
		}
	
		if ($_POST ['operation'] == "mul")

		{
			$somme = $_POST ['val1'] * $_POST ['val2'];
			echo "La somm est de " . $somme;	
		}
		if ($_POST ['operation'] == "div")

		{
			if ($_POST['val2'] == 0)
			{
				echo "Division par zéro est impossible";
			}
			else
			{
				$division = $_POST['val1'] / $_POST['val2'];
				echo "La division est de" . $division;
			}	
		}
	
?>



</body>
</html>