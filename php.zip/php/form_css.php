<html>
<body>

	
	<form method="POST" action="rez_css.php">
			<select name="theme">
			<option value="theme1" > Th�me 1 </option>
			<option value="theme2" > Th�me 2 </option>
			</select>
			<input type="submit"  value="envoyer" >
	</form>
		

</body>
</html>