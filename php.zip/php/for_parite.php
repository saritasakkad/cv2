<html>
<body>

<form method="POST" action="res_parite.php">

<p>

<label>Entre une valeur</label>
<input type="text" name="valeur" />

</p>

<p>

<input type="submit" value="Envoyer" />

</p>

</form>

</body>
</html>