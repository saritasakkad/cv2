<html>
<head>
<title> QCM </title>
</head>
<body>



 

   <form method="POST"    action="qcm.php">


   
	<p>
				 <fieldset>
				 
				 <legend>Question 1 : Combien de temps de temps faut-il</legend>
				
				<p> <input type="radio" name="Q1" value="R1"> </input> 
						<label>7,5 millions d'ann�es</label> </p>
						
						
						
   				<p> <input type="radio"  name="Q2" value="R2"> </input> 
								<label>20 ans</label> </p>
				
	
				
				<p> <input type="radio"  name="Q3" value="R3"> </input>
							<label>2 minutes</label> </p>
				</p>
				
				</fieldset>
  
  	<p>
				 <fieldset>
				 
				 
				 
				 <legend>Question 2 : Que'est-qui est jaune et dangereux</legend>
				
				<p> <input type="radio" name="Q1" value="R1"> </input> <label>Bart De Wever</label> </p>
   				<p> <input type="radio"  name="Q2" value="R2"> </input> <label>Un flan infest</label> </p>
				<p> <input type="radio"  name="Q3" value="R3"> </input> <label>fouad</label> </p>
				</p>
				</fieldset>
  	<p>
				 <fieldset>
				 
				 <legend>Quelle largeur fait akkad</legend>
				
				<p> <input type="radio" name="Q1" value="R1"> </input> <label>69</label> </p>
   				<p> <input type="radio" name="Q2" value="R2"> </input> <label>180</label> </p>
				<p> <input type="radio" name="Q3" value="R3"> </input> <label>38</label> </p>
				</p>
				</fieldset>


				
				<p><input type="submit" name="resultat"  value="resultat" ></p>

</form>  

<div id="score">


<?php 
	if(isset($_POST['resultat']))
	{
	$score =0;
	if(isset($_POST['Q1']))
	{
		if($_POST['Q1']=="R1")
	{
	
		$score++;
	}
	}
	
	
	
	if(isset($_POST['Q2']))
	{
		if($_POST['Q2']=="R2")
	{
	
		$score++;
	}
	}
	
	
	
	if(isset($_POST['Q3']))
	{
		if($_POST['Q3']=="R3")
	{
		$score++;
	}
	
	}
		echo "Votre score est de " . $score . "/3";
		
	}
?>
</div>        
</body>
</html>