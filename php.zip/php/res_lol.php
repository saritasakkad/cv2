<html>
<body>


<div>


		<?php
				// Permet d'afficher la phrase 
				echo "Bonjour " . $_POST["nom"] . " " . $_POST["prenom"] ;
			
				
				/*
				echo "<br/>" ;
				echo "test" ;
				*/
				
		?>	
		
</div>
</body>
</html>