<html>
<body>

	<table border="1">
	<?php
		for($i=1;$i<=10;$i++) //$i = 1
		{
?>
	<tr>
<?php
	for($j=1;$j<=10;$j++) // $j = 1 
	{
?>

	<td><?php echo $i*$j ; ?></td> 
<?php
	}
?>
	</tr>
<?php
	}
?>
	</table>
</body>
</html>