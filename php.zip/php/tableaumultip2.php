<html>
<body>

	<table border="1">
	<?php
		 $i=1;
		while ($i<=10)
		{
?>
	<tr>
<?php
	 $j=1;
	while ($j<=10)
	{
?>

	<td><?php echo $i*$j ; ?></td> 

	
<?php  $j++; 
	}
?></tr>
<?php   $i++;
}
?>
	</table>
</body>
</html>