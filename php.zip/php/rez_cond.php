<html>
<body>
		<?php
				if($_GET["valeur"] > 10)
					
				{
					echo "message1";	
				}
				else
				{
					if($_GET["valeur"] < 10) {
					echo "message2";	
				}		
				else
				{
					
					echo "message3";	
				}
					
			}
				
		?>
</body>
</html>