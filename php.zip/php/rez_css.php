<html>
<head>
<style>

 #theme1{
	 background : #254;
	 width : 300px;
	 height : 600px;
	 
 }
 
 #theme2{
	 background : #279;
	 width : 300px;
	 height : 600px;
	 
 }


</style>





</head>



<body>



<div id="<?php echo $_POST['theme']; ?>">
	
	contenu
		
</div>



</body>
</html>