<?php if(isset ($_POST['theme']))
{
	$theme = $_POST['theme'];
}
else
{
$theme = "theme1";	
}
?>
<html>
<head>
<style>

 #theme1{
	 background : #254;
	 background-image:url(198570.png);
	 width : 1440px;
	 height : 720px;
	 
 }
 
 #theme2{
	 background : #279;
	 background-image:url(effetretro.jpg);
	 width : 300px;
	 height : 600px;
	 
 }


</style>



</head>


<body>

	
	<form method="POST" action="rez_css.php">
			<select name="theme">
			<option value="theme1" > Th�me 1 </option>
			<option value="theme2" > Th�me 2 </option>
			</select>
			<input type="submit"  value="envoyer" >
	</form>
	
<div id="<?php echo $theme; ?>">
	
	contenu
		
</div>	

</body>
</html>