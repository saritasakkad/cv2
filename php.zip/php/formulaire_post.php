<html>
<body>
<div>
	
	<form method="POST" action="trait_post.php">
	<p>
			<label> Recherche un mot cl� </label>
	</p>
	
	<p>
			<input type="text" name="recherche" value="" >
	</p>
	
	<p>
			<input type="submit"  value="envoyer" >
	</p>
	</form>
		
</div>
</body>
</html>