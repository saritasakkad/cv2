<html>
<body>

	
	<form method="POST" action="admin.php">
	
	<p>
			<label> Login </label>
			<input type="text" name="ident"  >
	</p>
	<p>
			<label> Mot de passe </label>
			<input type="password" name="mdp"  >
	</p>
	<p>
			<input type="submit" value="Envoyer" >
	</p>
	</form>
		

</body>
</html>