<html>
<body>

    <form method="POST" 
	        action="res_lol.php" >
                 <p>
                    <label>Entrer votre nom</label>
                      <input type="text"  name="nom" />
                        </p>
						
						<p>
						<label>Entrer votre pr�nom</label>
						<input type="text"  name="prenom" />
                        </p>
						
						
                      <p>
                   <input type="submit"  value="envoyer" />
                 </p>
		
</form>
</body>
</html>