<html>
<body>

<table border="1">

	<?php
			for($i=0;$i<=10;$i++)
			{
		?>	
<tr>
	<th><?php echo $i ; ?></th>
</tr>	
		<?php		
			}
			
		?>	

</table>

	
		

</body>
</html>