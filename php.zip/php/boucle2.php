<html>
<body>


		<?php
			for($cpt=1;$cpt<=10;$cpt++)
			{
				echo "ligne num�ro " . $cpt . "<br />";
				
				
			}
			
		?>	
		

</body>
</html>