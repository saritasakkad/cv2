﻿<html>
<body>
<div>
	
	<form method="GET" action="trait_get.php">
	<p>
			<label> Recherche un mot clé </label>
	</p>
	
	<p>
			<input type="text" name="recherche" value="" >
	</p>
	<p>
			<input type="password" name="mdp" value="" >
	</p>
	<p>
			<input type="submit" name="envoyer" value="envoyer" >
	</p>
	</form>
		
</div>
</body>
</html>